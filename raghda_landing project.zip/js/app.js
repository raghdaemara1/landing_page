/**
 * 
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 * 
 * Dependencies: None
 * 
 * JS Version: ES2015/ES6
 * 
 * JS Standard: ESlint
 const link =  document.querySelector('li[data-nav="' + active_section.id + '"]');
	const navbar_list = document.querySelectorAll('.menu_link');
	let section_nav = active_section.getAttribute('data-nav');
	console.log(navbar_list);
	
	
	navbar_list.forEach( item =>{
		link.classList.add('active_link');
	if(link.textContent !== section_nav){
		item.classList.remove('active_link');

	}
	else{
		link.classList.add('active_link');
	}
	});
	 const active_link = document.querySelector('a');
	 console.log('li[data-nav="' + active_section.id + '"]');
     active_link.classList.add('active__link');
     const navbar_list = document.querySelectorAll('.menu__link');
     navbar_list.forEach( item =>{
        if (item.dataset.nav != active_link .dataset.nav ) {
            item.classList.remove('active__link');
            }
        });
	
 * 
*/

/**
 * Define Global Variables
 * 
*/
const sections = document.querySelectorAll('section');
const nav = document.querySelector('#navbar__list');

/**
 * End Global Variables
 * Start Helper Functions
 * 
*/

//I Added getActiveLink to set the selected section link as active while scrolling

function getActiveLink(active_section){
	const active_link=  document.querySelector('li[data-nav="' + active_section.id + '"]');
   const link = active_section.getAttribute('data-nav');
    const navbar_list = document.querySelectorAll('.menu__link'); 

    active_link.classList.add('active__link');

     
    navbar_list.forEach( item =>{
        if (item.textContent!= link) {
            item.classList.remove('active__link');
            }
        });
    


};


/**
 * End Helper Functions
 * Begin Main Functions
 * 
*/

// build the nav
//I created a foreach loop that will iterate all the sections in the html code to add them dynamically and set theier id and class name

function addSection() {
   sections.forEach(section =>{
		var item = document.createElement("li");
		item.setAttribute("class", "menu__link");
		item.setAttribute("data-nav", section.id);
		item.innerText= section.dataset.nav;
        nav.appendChild(item);
    });
    
};



// Add class 'active' to section when near top of viewport
//I added an eventlistener to know which section is the viewport to know which one is active 
function setActive(){
window.addEventListener('scroll', function() {
	
	sections.forEach( (section) => {
	let rect = section.getBoundingClientRect();
	if(rect.top >=-300 && rect.top <300){ 
		section.classList.add('your-active-class');
		 getActiveLink(section);
	}
		// set other sections as inactive
	else {
		section.classList.remove('your-active-class');
	}



});
		
	
});
}

// Scroll to anchor ID using scrollTO event 
//i added a smooth behavior while scrolling and going to the clicked section 
function scrollToClick() {
    nav.addEventListener('click', function (event) {
        const section_clicked = document.getElementById(event.target.dataset.nav);
       
        section_clicked.scrollIntoView({behavior: "smooth"});
    });
};

/**
 * End Main Functions
 * Begin Events
 * 
*/

// Build menu 
addSection();
// Scroll to section on link click
scrollToClick();
// Set sections as active
setActive();


