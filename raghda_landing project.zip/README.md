# Landing Page Project

The Landing Page Project is the first project required by Udacity in [Web Development Professional Nanodegree  Program](https://www.udacity.com/course/front-end-web-developer-nanodegree--nd0011) In [Egypt FWD Program](https://egfwd.com/web/)

## Table of Contents

* [Introduction](#introduction)
* [Project Structure](#projectstructure)
* [How To Open](#howtoopen)

## Introduction
	
The Project is a Landing page that do the following steps:
    - Navigation is built dynamically as an unordered list
    - It is highlights which section is being viewed while scrolling through the page with active state class
    - When clicking an item from the navigation menu, the link is scrolling to the appropriate section.

## Project Structure

 root_css/styles.css
    |_js/app.js
    |__index.html
    |__README.md


## How To Open

You can preview the page using [this link]
